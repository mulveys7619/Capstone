/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capstoneproject;

/**
 *
 * @author smgco
 */
public class CurrGame 
{
    public static int gameID;
    
    public static void SetGameID(int id)
    {
        gameID = id;
    }
    public static int GetGameID()
    {
        return gameID;
    }
    
}
