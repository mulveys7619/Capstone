/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capstoneproject;


import capstoneproject.CurrGame;
import GameForms.GameFormTemplate;
import GameForms.AssassinsCreed;
import GameForms.FillForms;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.*;
import java.awt.event.*;
import java.net.URL;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.sql.*;
import javax.imageio.ImageIO;


/**
 *
 * @author smgco
 */

public class AddGames extends javax.swing.JFrame {
    public ImageIcon imgIconP;

    // <editor-fold defaultstate="collapsed" desc="Declare Kanit Font Variables">
    public static Font kanitEB,
                       kanitBl,
                       kanitBlI,
                       kanitB,
                       kanitBI,
                       kanitEBI,
                       kanitEL,
                       kanitELI,
                       kanitI,
                       kanitL,
                       kanitLI,
                       kanitM,
                       kanitMI,
                       kanitR,
                       kanitSB,
                       kanitSBI,
                       kanitT,
                       kanitTI;
    // </editor-fold>
    /**
     * Creates new form AddGames
     */
    public AddGames() {
        initComponents();
        ImportFonts();
        FormatNavbar();
        FormatBody();
        
        
    }
    
    // <editor-fold defaultstate="collapsed" desc="void ImportFonts() -- Create Kanit Font Family">
    private void ImportFonts()
    {
        
        try
        {
            
            kanitEB = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraBold.ttf"));
            GraphicsEnvironment geKEB = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKEB.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraBold.ttf")));
            
            
            kanitBl = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Black.ttf"));
            GraphicsEnvironment geKBl = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKBl.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Black.ttf")));
            
            
            kanitBlI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-BlackItalic.ttf"));
            GraphicsEnvironment geKBlI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKBlI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-BlackItalic.ttf")));
            
            
            kanitB = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Bold.ttf"));
            GraphicsEnvironment geKB = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKB.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Bold.ttf")));
            
            
            kanitBI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-BoldItalic.ttf"));
            GraphicsEnvironment geKBI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKBI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-BoldItalic.ttf")));
            
            
            kanitEBI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraBoldItalic.ttf"));
            GraphicsEnvironment geKEBI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKEBI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraBoldItalic.ttf")));
            
            
            kanitEL = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraLight.ttf"));
            GraphicsEnvironment geKEL = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKEL.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraLight.ttf")));
            
            
            kanitELI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraLightItalic.ttf"));
            GraphicsEnvironment geKELI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKELI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ExtraLightItalic.ttf")));
            
            
            kanitI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Italic.ttf"));
            GraphicsEnvironment geKI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Italic.ttf")));
            
            
            kanitL = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Light.ttf"));
            GraphicsEnvironment geKL = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKL.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Light.ttf")));
            
            
            kanitLI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-LightItalic.ttf"));
            GraphicsEnvironment geKLI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKLI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-LightItalic.ttf")));
            
           
            kanitM = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Medium.ttf"));
            GraphicsEnvironment geKM = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKM.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Medium.ttf")));
            
            
            kanitMI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-MediumItalic.ttf"));
            GraphicsEnvironment geKMI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKMI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-MediumItalic.ttf")));
            
            
            kanitR = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Regular.ttf"));
            GraphicsEnvironment geKR = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKR.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Regular.ttf")));
            
            
            kanitSB = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-SemiBold.ttf"));
            GraphicsEnvironment geKSB = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKSB.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-SemiBold.ttf")));
            
            
            kanitSBI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-SemiBoldItalic.ttf"));
            GraphicsEnvironment geKSBI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKSBI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-SemiBoldItalic.ttf")));
            
            
            kanitT = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Thin.ttf"));
            GraphicsEnvironment geKT = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKT.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-Thin.ttf")));
            
            
            kanitTI = Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ThinItalic.ttf"));
            GraphicsEnvironment geKTI = GraphicsEnvironment.getLocalGraphicsEnvironment();
            geKTI.registerFont(Font.createFont(Font.TRUETYPE_FONT, new File("src\\Fonts\\Kanit-ThinItalic.ttf")));
            
        }
        catch(IOException | FontFormatException e)
        {
            System.out.println(e);
        }
    }
   // </editor-fold> 
    // <editor-fold defaultstate="collapsed" desc="void FormatNavbar() -- Formatting For Nav Bar On Forms">
    private void FormatNavbar()
    {
        cap_nav.setFont(kanitEB.deriveFont(48f));
        cap_nav.setText("Capstone");
        cap_nav.setForeground(Color.WHITE);
    }
    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="void FormatBody() -- Formatting For Body On  AddGames">
    private void FormatBody()
   {
       
       int gameID = CurrGame.GetGameID();
       String path = "";
       Color combobg = new Color(44,57,51);
       Color combol = new Color(51,51,55);
       
       
       try
       {
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/DB","root","root");
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
           
       }
       catch(Exception e)
       {
           JOptionPane.showMessageDialog(null, e);
       }
       
       
       
       
       
        
        
   }
   // </editor-fold>

  
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        cap_nav = new javax.swing.JLabel();
        formDesc = new javax.swing.JLabel();
        titleLabel = new javax.swing.JLabel();
        sub1Label = new javax.swing.JLabel();
        sub2Label = new javax.swing.JLabel();
        sub3Label = new javax.swing.JLabel();
        gameDescLabel = new javax.swing.JLabel();
        titleText = new javax.swing.JTextField();
        cancelButton = new javax.swing.JButton();
        requiredFieldLabel = new javax.swing.JLabel();
        submitButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        gameDescText = new javax.swing.JTextArea();
        sub3Combo = new javax.swing.JComboBox<>();
        sub2Combo = new javax.swing.JComboBox<>();
        sub1Combo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1400, 800));

        mainPanel.setBackground(new java.awt.Color(35, 39, 42));
        mainPanel.setPreferredSize(new java.awt.Dimension(1233, 695));

        jPanel1.setBackground(new java.awt.Color(102, 0, 153));
        jPanel1.setForeground(new java.awt.Color(102, 0, 153));

        cap_nav.setFont(new java.awt.Font("Kanit ExtraBold", 0, 48)); // NOI18N
        cap_nav.setForeground(new java.awt.Color(255, 255, 255));
        cap_nav.setText("Capstone");
        cap_nav.setName(""); // NOI18N
        cap_nav.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cap_navMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cap_nav, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1216, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(cap_nav, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        formDesc.setFont(new java.awt.Font("Kanit SemiBold", 2, 36)); // NOI18N
        formDesc.setForeground(new java.awt.Color(255, 255, 255));
        formDesc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        formDesc.setText("ADD A GAME TO CAPSTONE");

        titleLabel.setFont(new java.awt.Font("Kanit", 3, 24)); // NOI18N
        titleLabel.setForeground(new java.awt.Color(255, 255, 255));
        titleLabel.setText("ADD TITLE *");

        sub1Label.setFont(new java.awt.Font("Kanit", 3, 24)); // NOI18N
        sub1Label.setForeground(new java.awt.Color(255, 255, 255));
        sub1Label.setText("ADD GENRE *");

        sub2Label.setFont(new java.awt.Font("Kanit", 3, 24)); // NOI18N
        sub2Label.setForeground(new java.awt.Color(255, 255, 255));
        sub2Label.setText("ADD SUBGENRE");

        sub3Label.setFont(new java.awt.Font("Kanit", 3, 24)); // NOI18N
        sub3Label.setForeground(new java.awt.Color(255, 255, 255));
        sub3Label.setText("ADD SUBGENRE");

        gameDescLabel.setFont(new java.awt.Font("Kanit", 3, 24)); // NOI18N
        gameDescLabel.setForeground(new java.awt.Color(255, 255, 255));
        gameDescLabel.setText("ADD DESCRIPTION");

        titleText.setBackground(new java.awt.Color(44, 47, 51));
        titleText.setFont(new java.awt.Font("Kanit Light", 3, 18)); // NOI18N
        titleText.setForeground(new java.awt.Color(255, 255, 255));
        titleText.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        cancelButton.setBackground(new java.awt.Color(44, 47, 51));
        cancelButton.setFont(new java.awt.Font("Kanit Light", 0, 11)); // NOI18N
        cancelButton.setForeground(new java.awt.Color(255, 255, 255));
        cancelButton.setText("Cancel");
        cancelButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelButtonMouseClicked(evt);
            }
        });

        requiredFieldLabel.setFont(new java.awt.Font("Kanit ExtraLight", 3, 14)); // NOI18N
        requiredFieldLabel.setForeground(new java.awt.Color(255, 255, 255));
        requiredFieldLabel.setText("* denotes a required field");

        submitButton.setBackground(new java.awt.Color(44, 47, 51));
        submitButton.setFont(new java.awt.Font("Kanit Light", 0, 11)); // NOI18N
        submitButton.setForeground(new java.awt.Color(255, 255, 255));
        submitButton.setText("Submit");
        submitButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                submitButtonMouseClicked(evt);
            }
        });

        gameDescText.setBackground(new java.awt.Color(44, 47, 51));
        gameDescText.setColumns(20);
        gameDescText.setFont(new java.awt.Font("Kanit Medium", 3, 14)); // NOI18N
        gameDescText.setForeground(new java.awt.Color(255, 255, 255));
        gameDescText.setLineWrap(true);
        gameDescText.setRows(5);
        jScrollPane1.setViewportView(gameDescText);

        sub3Combo.setFont(new java.awt.Font("Kanit ExtraLight", 1, 14)); // NOI18N
        sub3Combo.setForeground(new java.awt.Color(255, 255, 255));
        sub3Combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NONE", "JRPG", "ARPG", "MMORPG", "ROGUE", "TURN BASED", "TACTICS", "OPEN WORLD" }));

        sub2Combo.setFont(new java.awt.Font("Kanit ExtraLight", 1, 14)); // NOI18N
        sub2Combo.setForeground(new java.awt.Color(255, 255, 255));
        sub2Combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NONE", "JRPG", "ARPG", "MMORPG", "ROGUE", "TURN BASED", "TACTICS", "OPEN WORLD" }));

        sub1Combo.setFont(new java.awt.Font("Kanit ExtraLight", 1, 14)); // NOI18N
        sub1Combo.setForeground(new java.awt.Color(255, 255, 255));
        sub1Combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NONE", "JRPG", "ARPG", "MMORPG", "ROGUE", "TURN BASED", "TACTICS", "OPEN WORLD" }));

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(formDesc)
                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(sub1Combo, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(mainPanelLayout.createSequentialGroup()
                            .addComponent(sub2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(sub2Combo, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addComponent(sub3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(sub3Combo, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(gameDescLabel)
                    .addComponent(jScrollPane1))
                .addGap(18, 18, 18)
                .addComponent(requiredFieldLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(titleLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(sub1Label, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(titleText, javax.swing.GroupLayout.PREFERRED_SIZE, 532, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(720, Short.MAX_VALUE)))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(requiredFieldLabel, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(formDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(122, 122, 122)
                        .addComponent(sub1Combo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sub2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sub2Combo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sub3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sub3Combo, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(gameDescLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(mainPanelLayout.createSequentialGroup()
                    .addGap(180, 180, 180)
                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(titleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(titleText, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(sub1Label, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(507, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 1458, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mainPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 784, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cap_navMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cap_navMouseClicked
        HomePage home = new HomePage();
        dispose();
        home.show();
    }//GEN-LAST:event_cap_navMouseClicked

    private void cancelButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelButtonMouseClicked
        HomePage home = new HomePage();
        dispose();
        home.show();
    }//GEN-LAST:event_cancelButtonMouseClicked

    private void submitButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_submitButtonMouseClicked
         try
       {
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/DB","root","root");
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            
            String path = "",
                   title = "",
                   desc = "";
            int id = 0,
                sub1 = 0,
                sub2 = 0,
                sub3 = 0;
            
            
            // DETERMINE GAME_ID FIELD
            String countQuery = "SELECT COUNT(*) FROM games";
            ResultSet countRS = st.executeQuery(countQuery);
            countRS.next();
            int result = countRS.getInt(1);
            id = result + 1;
            
            // DETERMINE TITLE FIELD
            title = titleText.getText();
            
            //DETERMINE PATH FIELD
            path = "usergame";
            
            // DETERMINE DESCRIPTION FIELD
            desc = gameDescText.getText();
            
            // DETERMINE GENRE FIELDS
            int combo1 = sub1Combo.getSelectedIndex();
            int combo2 = sub2Combo.getSelectedIndex();
            int combo3 = sub3Combo.getSelectedIndex();
            switch(combo1)
            {
                case 0:
                    sub1 = 8;
                    break;
                case 1:
                    sub1 = 1;
                    break;
                case 2:
                    sub1 = 2;
                    break;
                case 3:
                    sub1 = 3;
                    break;
                case 4:
                    sub1 = 4;
                    break;
                case 5:
                    sub1 = 5;
                    break;
                case 6:
                    sub1 = 6;
                    break;
                case 7:
                    sub1 = 7;
                    break;
                default:
                    sub1 = 8;
            }
            switch(combo2)
            {
                case 0:
                    sub2 = 8;
                    break;
                case 1:
                    sub2 = 1;
                    break;
                case 2:
                    sub2 = 2;
                    break;
                case 3:
                    sub2 = 3;
                    break;
                case 4:
                    sub2 = 4;
                    break;
                case 5:
                    sub2 = 5;
                    break;
                case 6:
                    sub2 = 6;
                    break;
                case 7:
                    sub2 = 7;
                    break;
                default:
                    sub2 = 8;
            }
            switch(combo3)
            {
                case 0:
                    sub3 = 8;
                    break;
                case 1:
                    sub3 = 1;
                    break;
                case 2:
                    sub3 = 2;
                    break;
                case 3:
                    sub3 = 3;
                    break;
                case 4:
                    sub3 = 4;
                    break;
                case 5:
                    sub3 = 5;
                    break;
                case 6:
                    sub3 = 6;
                    break;
                case 7:
                    sub3 = 7;
                    break;
                default:
                    sub3 = 8;
            }
            
            
            // ADD RECORD TO GAMES TABLE
            String addRecord = "INSERT INTO games VALUES(?,?,?,?,?,?,?)";
            PreparedStatement addRecordPS = con.prepareStatement(addRecord);
            addRecordPS.setInt(1, id);
            addRecordPS.setString(2, path);
            addRecordPS.setString(3, title);
            addRecordPS.setString(4, desc);
            addRecordPS.setInt(5, sub1);
            addRecordPS.setInt(6, sub2);
            addRecordPS.setInt(7, sub3);
            addRecordPS.executeUpdate();
            
            
            con.close();
            
            JOptionPane.showMessageDialog(null, "Game Added");
            HomePage home = new HomePage();
            dispose();
            home.show();
            
       }
       catch(Exception e)
       {
           JOptionPane.showMessageDialog(null, e);
       }
    }//GEN-LAST:event_submitButtonMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddGames.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddGames.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddGames.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddGames.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddGames().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel cap_nav;
    private javax.swing.JLabel formDesc;
    private javax.swing.JLabel gameDescLabel;
    private javax.swing.JTextArea gameDescText;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JLabel requiredFieldLabel;
    private javax.swing.JComboBox<String> sub1Combo;
    private javax.swing.JLabel sub1Label;
    private javax.swing.JComboBox<String> sub2Combo;
    private javax.swing.JLabel sub2Label;
    private javax.swing.JComboBox<String> sub3Combo;
    private javax.swing.JLabel sub3Label;
    private javax.swing.JButton submitButton;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JTextField titleText;
    // End of variables declaration//GEN-END:variables
}
